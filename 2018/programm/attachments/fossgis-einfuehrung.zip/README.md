# fossgis-oss

Starting Presentation FOSSGIS Conferences 

- Work in progress

Images from `FOSSGIS e.V.` <http://fossgis.de> or from `OSGeo Live DVD` <http://live.osgeo.org>
