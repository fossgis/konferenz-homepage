SELECT 
ST_Union(geometry),
KRID AS KRID,
lkr_NAMR AS name, 
SUM(EWZ) AS EWZ,
to_int(AVG(EWZ)) AS mittelwert,
COUNT(GEN) AS Anzahl,
Group_concat(GEN,', ') AS liste
FROM 'niedersachsen_EW_lkr2' 
GROUP BY lkr_NAMR

SELECT 
CastToMultiPolygon(ST_Union(GEOMETRY)) AS GEOMETRY,
KRID AS KRID,
lkr_NAMR AS name, 
SUM(EWZ) AS EWZ,
round(AVG(EWZ)) AS mittelwert,
COUNT(GEN) AS Anzahl,
Group_concat(GEN,', ') AS liste
FROM 'gemew'
GROUP BY lkr_NAMR

SELECT 
CastToMultiPolygon(ST_Union(GEOMETRY)) AS GEOMETRY,
KRID AS KRID,
lkr_NAMR AS name, 
SUM(EWZ) AS EWZ,
CastToInteger(AVG(EWZ)) AS mittelwert,
COUNT(GEN) AS Anzahl,
Group_concat(GEN,', ') AS liste
FROM 'gemew'
GROUP BY lkr_NAMR

SELECT 
CastToMultiPolygon(ST_Union(geometry)) AS geometry,
krid AS krid,
NAMR AS name, 
SUM(EW) AS EWZ,
CastToInteger(AVG(EW)) AS mittelwert,
COUNT(gen) AS Anzahl,
Group_concat(gen,', ') AS liste
FROM 'nieders_mit_daten'
GROUP BY NAMR

create table krneupol AS
SELECT 
CasttoPolygon(ST_Union(GEOMETRY)) AS GEOMETRY,
KRID AS KRID,
lkr_NAMR AS name, 
SUM(EWZ) AS EWZ,
CastToInteger(AVG(EWZ)) AS mittelwert,
COUNT(GEN) AS Anzahl,
Group_concat(GEN,', ') AS liste
FROM 'gemew'
GROUP BY lkr_NAMR

---------------
ogr2ogr -f gpkg -sql "SELECT CastToMultiPolygon(GUnion(geometry)) AS geometry, \
krid AS krid, NAMR AS name, SUM(EW) AS EWZ, CastToInteger(AVG(EW)) AS mittelwert, COUNT(gen) AS Anzahl, \
Group_concat(gen,', ') AS liste FROM 'nieders_mit_daten' GROUP BY NAMR" \
-dialect sqlite dissolve.gpkg nieders_mit_daten.shp

ogr2ogr -f SQLite -dsco SPATIALITE=yes -lco SRID=25832 -nln kreise -lco COMPRESS_GEOM=YES -skipfailures -gt 65536 -a_srs EPSG:25832 \
-sql "SELECT CastToMultiPolygon(GUnion(geometry)) AS geometry,krid AS krid, NAMR AS name, SUM(EW) AS EWZ, \
CastToInteger(AVG(EW)) AS mittelwert, COUNT(gen) AS Anzahl, Group_concat(gen,', ') AS liste FROM 'nieders_mit_daten' \
GROUP BY NAMR" -dialect sqlite " diss.sqlite" nieders_mit_daten.shp





