
CREATE TRIGGER flb_update  -- Ein trigger wird angelegt
after update of geometry   -- Ausgelöst von jeder Änderung der Geometrie
on layername		   -- auf dem layer laysername
begin
update layername set ha = (st_area(geometry)) / 10000  -- Die Spalte ha des Layers layername wird neu berechnet (Die Fläche der Geometry / 10000 ergibt ha)
where rowid = new.rowid;   -- Nur die Zeilen der geänderten Geometrien werden aktualisiert
end


CREATE TRIGGER flb_insert
after insert on layername  -- Ausgelöst vom neuanlegen einer Geometrie
begin
update layername set ha = (st_area(geometry)) / 10000
where rowid = new.rowid;
end 
