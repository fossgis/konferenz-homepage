Select
Hessen.Geometry AS Geometry,
Hessen.RS AS RS,
Hessen.GEN AS GEN,
EW.EWZ AS EWZ,
round((area(Gunion(ST_Intersection(Hessen.Geometry,DLM250.Geometry))) / 1000000),2) AS WFL,
round((area(Gunion(ST_Intersection(Hessen.Geometry,DLM250.Geometry)))) / (area(Hessen.Geometry))* 100) AS anteil,
round((area(Gunion(ST_Intersection(Hessen.Geometry,DLM250.Geometry)))) / EW.EWZ)  AS WF_EW
from
(Hessen inner join DLM250 ON intersects(Hessen.Geometry,DLM250.Geometry)) inner join EW ON EW.RS = Hessen.RS
where DLM250.Veget = 'AX_Wald'
Group by Hessen.RS

Select
gemeinden_etrs89.Geometry AS Geometry,
gemeinden_etrs89.RS AS RS,
gemeinden_etrs89.GEN AS GEN,
EWZ.EWZ AS EWZ,
round((area(Gunion(ST_Intersection(gemeinden_etrs89.Geometry,DLM250etrs.Geometry))) / 1000000),2) AS WFL,
round((area(Gunion(ST_Intersection(gemeinden_etrs89.Geometry,DLM250etrs.Geometry)))) / (area(gemeinden_etrs89.Geometry))* 100) AS anteil,
round((area(Gunion(ST_Intersection(gemeinden_etrs89.Geometry,DLM250etrs.Geometry)))) / EWZ.EWZ)  AS WF_EW
from
(gemeinden_etrs89 inner join DLM250etrs ON intersects(gemeinden_etrs89.Geometry,DLM250etrs.Geometry)) inner join EWZ ON EWZ.RS = gemeinden_etrs89.RS
where DLM250etrs.Veget = 'AX_Wald'
Group by gemeinden_etrs89.RS

Select
gemeinden.Geom AS Geom,
gemeinden.RS AS RS,
gemeinden.GEN AS GEN,
EWZ.EWZ AS EWZ,
round((area(Gunion(ST_Intersection(gemeinden.Geom,DLM250.Geom))) / 1000000),2) AS WFL,
round((area(Gunion(ST_Intersection(gemeinden.Geom,DLM250.Geom)))) / (area(gemeinden.Geom))* 100) AS anteil,
round((area(Gunion(ST_Intersection(gemeinden.Geom,DLM250.Geom)))) / EWZ.EWZ)  AS WF_EW
from
(gemeinden inner join DLM250 ON intersects(gemeinden.Geom,DLM250.Geom)) inner join EWZ ON EWZ.RS = gemeinden.RS
where DLM250.Veget = 'AX_Wald'
Group by gemeinden.RS


---Verschachtelete Funktionen mit räumlichen Index
Select
gemeinden.Geom AS Geom,
gemeinden.RS AS RS,
gemeinden.GEN AS GEN,
EWZ.EWZ AS EWZ,
round((area(Gunion(ST_Intersection(gemeinden.Geom,DLM250.Geom))) / 1000000),2) AS WFL,
round((area(Gunion(ST_Intersection(gemeinden.Geom,DLM250.Geom)))) / (area(gemeinden.Geom))* 100) AS anteil,
round((area(Gunion(ST_Intersection(gemeinden.Geom,DLM250.Geom)))) / EWZ.EWZ)  AS WF_EW
from
(gemeinden left join DLM250 ON intersects(gemeinden.Geom,DLM250.Geom)) left join EWZ ON EWZ.RS = gemeinden.RS
where DLM250.ROWID IN
            (SELECT ROWID FROM SpatialIndex WHERE f_table_name='DLM250' AND search_frame=gemeinden.Geom)
   and
    DLM250.Veget = 'AX_Wald'
Group by gemeinden.RS


---- verschchtelete gesamtabfrage
Select
g.Geom AS Geom,
g.RS AS RS,
g.GEN AS GEN,
g.EWZ AS EWZ,
round((area(i.Geom) / 1000000),2) AS WFL,
round((area(i.Geom)  / (area(g.Geom))* 100)) AS anteil,
round(area(i.Geom)  / g.EWZ)  AS WF_EW
from
  (Select
  g.Geom AS Geom,
  g.RS AS RS,
  g.GEN AS GEN,
  e.EWZ AS EWZ
  from
   gemeinden as g  inner join EWZ as e ON (e.RS = g.RS))
as g
left join
  (select
  RS,
  Gunion(geom) as geom
  from
   (Select
    gemeinden.RS AS RS,
    gemeinden.GEN AS GEN,
    ST_Intersection(gemeinden.Geom,DLM250.Geom) AS geom
    from
    gemeinden  left join DLM250  ON intersects(gemeinden.Geom,DLM250.Geom)
    where DLM250.ROWID IN
            (SELECT ROWID FROM SpatialIndex WHERE f_table_name='DLM250' AND search_frame=gemeinden.Geom)
   and
    DLM250.Veget = 'AX_Wald')
 group by RS)
as i
on (i.RS = g.RS)

------- teiel
select
RS,
casttopolygon(Gunion(geom)) as geom
from
(Select
gemeinden.RS AS RS,
gemeinden.GEN AS GEN,
ST_Intersection(gemeinden.Geom,DLM250.Geom) AS geom
from
gemeinden  left join DLM250  ON intersects(gemeinden.Geom,DLM250.Geom)
where DLM250.ROWID IN
            (SELECT ROWID FROM SpatialIndex WHERE f_table_name='DLM250' AND search_frame=gemeinden.Geom)
and
DLM250.Veget = 'AX_Wald')
group by RS)
as i


Select
g.Geom AS Geom,
g.RS AS RS,
g.GEN AS GEN,
e.EWZ AS EWZ
from
gemeinden as g  inner join EWZ as e ON e.RS = g.RS)
as g


---- Create table hintereinander
create table gemewz as
Select
g.Geom AS Geom,
g.RS AS RS,
g.GEN AS GEN,
e.EWZ AS EWZ
from
gemeinden as g  inner join EWZ as e ON (e.RS = g.RS)
;

create table intersectum as
Select
    gemeinden.RS AS RS,
    gemeinden.GEN AS GEN,
    ST_Intersection(gemeinden.Geom,DLM250.Geom) AS geom
    from
    gemeinden  left join DLM250  ON intersects(gemeinden.Geom,DLM250.Geom)
    where DLM250.ROWID IN
            (SELECT ROWID FROM SpatialIndex WHERE f_table_name='DLM250' AND search_frame=gemeinden.Geom)
   and
    DLM250.Veget = 'AX_Wald';


create table wdissolve as
select
RS,
(Gunion(geom)) as geom
from
intersectum
group by RS;

create table waaanteil as
Select
g.Geom AS Geom,
g.RS AS RS,
g.GEN AS GEN,
g.EWZ AS EWZ,
round((area(i.Geom) / 1000000),2) AS WFL,
round((area(i.Geom)  / (area(g.Geom))* 100)) AS anteil,
round(area(i.Geom)  / g.EWZ)  AS WF_EW
from wdissolve as i left join gemewz as g on (i.RS = g.RS);

Select RecoverGeometryColumn("waaanteil",'Geom',25832,'MULTIPOLYGON');
Select CreateSpatialIndex("waaanteil",'Geom');

SELECT UpdateLayerStatistics('waaanteil');

drop table gemewz;
drop table intersectum;
drop table wdissolve;

