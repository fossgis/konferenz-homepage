---Folgelinien erzeugen.

Du erzeugst eine Linie zwischen einer Punktgeometrie und der Position des Labels über die Funktion MakeLine(Startpunkt, Zielpunkt). Wenn es sich um Polygone handelt, müsstest Du Dich z.B. auf das Centroid des Polygons beziehen.
------------------------
Prinzip des SQL-Aufrufs im virtuellen Layer:

Select
MakeLine(Startpunkt, Zielpunkt) As geometry
from Layer

------------------------
Startpunkt wäre die Punktgeometrie

Select
MakeLine(geometry, Zielpunkt) As geometry
from Layer

beim Polygon müsste das centroid verwendet werden oder PointOnSurface
Select
MakeLine(centroid(geometry), Zielpunkt) As geometry
from Layer
--------------------------
Der Zielpunkt (der Ort des Labels) wird aus einem WKT String mit der Funktion PointFromText erzeugt. Wobei die Koordinaten aus den Spalten xc und yc stammen, die für die datendefinierte und mausgesteuerte Platzierung des Labels angelegt worden sind.

PointFromText('POINT('||xc||' '||yc||')', 25832)
Mit Hilfe der Verkettungsoperatoren || wird der WKT-String erzeugt. Die Ziffer hinten ist der EPSG-Code des Koordinatensyswtems.
------------------------------------------------
Mit dem Aufruf
Select
MakeLine(geometry,
(PointFromText('POINT('||xc||' '||yc||')', 25832))
) As geometry
from
Layer

entsteht die Verbindungslinie.

--------------------------------------------------
Dort wo das Label nicht verschoben worden ist, sind keine Werte in der xc und xy Spalte, so dass die Spalte ausgeschlossen werden soll.

where xc is not NULL and yc is not NULL
----------------------------------------------
Gesamtaufruf für virtuellen layer:
(Layer hinzufügen > virtueller Layer)

Select
MakeLine(geometry,
(PointFromText('POINT('||xc||' '||yc||')', 25832))
) As geometry
from
Layer
where xc is not NULL and yc is not NULL

----------------------------------------
Im Geometriegenerator der Symbolsierung erreicht man das das Gleiche über:
Case
when  "xc" IS NOT NULL AND  "yc" IS NOT NULL
then
make_line($geometry,
geom_from_wkt('POINT('||xc||' '||yc||')')
)
end 