
'FOSSGIS 2016
SQL für QGIS und SpatiaLite.
Verschiedene Übungen 
'
'INFOS IM NETZ'
http://www.gaia-gis.it/gaia-sins/index.html
http://www.gaia-gis.it/gaia-sins/spatialite-sql-4.3.0.html
http://www.sqlite.org/lang.html
http://northredoubt.com/n/2012/10/19/spatialite-and-triggers-to-update-data/

https://www.surfaces.co.il/spatialite-speedup-your-query-with-spatial-indexing/
https://www.gaia-gis.it/fossil/libspatialite/wiki?name=SpatialIndex
-----



'LOS GEHTS!'

'SÄMTLICHE SHAPES AUS HESSEN IN EINE SPATIALITE-DATENBANK SCHREIBEN'
'DEN TEXT IN EINE EIGENE DATEI KOPIEREN UND ALS shp2sqlite in das Verzeichnis bin im Nutzerverzeichnis speichern'
#!/bin/bash
# shp2sqlite-Shapes zu SQLITE
for shps in *.shp; do
ogr2ogr --config OGR_SQLITE_SYNCHRONOUS OFF  --config OGR_SQLITE_CACHE 1024 -f "SQLite" -dsco SPATIALITE=yes -lco SRID=25832 -lco COMPRESS_GEOM=YES -nlt PROMOTE_TO_MULTI -skipfailures -append -gt 65536 -a_srs EPSG:25832 ziel.sqlite $shps
done
#csv-Dateien
for csvs in *.csv; do
ogr2ogr --config OGR_SQLITE_SYNCHRONOUS OFF  --config OGR_SQLITE_CACHE 1024 -f "SQLite" -update -append -skipfailures ziel.sqlite $csvs
done
# Excel-Dateien
for xlsxs in *.xlsx; do
ogr2ogr --config OGR_SQLITE_SYNCHRONOUS OFF  --config OGR_SQLITE_CACHE 1024 -f "SQLite" -update -append -skipfailures ziel.sqlite $xlsxs
done

'SPATIALITE_DATENBANK ANMELDEN'
Layer > Layer hinzufügen > SpatiaLite-Layer  hinzufügen
NEU klicken und Datenbank auswählen

'ERWEITERUNG QSPATIALITE INSTALLIEREN'
Erweiterungen > Erweiterungen verwalten und installieren

------
'EINGEBAMÖGLICHKEITEN FÜR SQL'
-- Virtuelle Layer
Layer > Layer hinzufügen > Virtuelle Layer
Zugriff auf alle geladenen Layer, virtueller layer wird dynamisch im Projekt erzeugt
Langsam!
SpatiaLite-SQL und alle Funktionen des Ausdruckseditors sind verfügbar.

---Verarbeitungs-Toolbox
QGIS-Geo-Algorithmen > Allgemeine Vektorwerkzeuge > SQL-Anweisung ausführen
Erzeugt einen neuen layer in einem beliebigen Format.
Direktes schreiben in SpatiaLite-Tabelle schlägt fehlt

GDAL/OGR > Verschiedenes > SQL-Anweisung ausführen
basiert auf ogr2ogr

---- Datenbankmanager
Datenbank > DB-Verwaltung > DB-Verwaltung
Dort SQL-Fenster öffnen
Über die kleine SQL-Schaltfläche ist eine grafische Hilfe verfügbar

---Erweiterung QSpatiaLite
Mit grafischer Engabehife,
Ermöglcht es eine weitere Befehle Primärschlüssel anzulegen und Geometriespalte zu definieren

---spatialitegui Dowmload auf der SpatiaLite-Wevseite
Eigenes Programm, erlaubt die Eingabe ganzer SQL-Skripte


'LANDKREISE AUS GEMEINDEN GENERIEREN'

-- Einwohner und Landkreistabelle als ewt und lkr über den DB-Manager laden
Datenbank > DB-Verwaltung > DB-Verwaltung
Dort: Tabelle > Layer importieren
Die Tabellen einwohner_he.xlsx (als ewz) und landkreise.csv (als lkr) importieren
Primärschlüssel und Codierung utf.8 wählen

'Inhalt anzeigen'
--qspatialite aufrufen: Datenbank > Spatialite > qspatialite
--Datenbank ziel.sqlite auswählen

-- Abfrage eingeben
select              -- Auswahl aus einer Tabelle
*                   -- sämtliche Spalten werden angezeigt
from hessen etrs    -- die Tabelle von der gewählt wird

--Bei der Abfrage einzelne Spalten angeben und mit einem Alias versehen
select 
rs as regionalschluessel, --Spalte rs wird als regionalschluessel angezeigt
gen as name               --Spalte gen wird aSl name angezeigt
from hessen etrs
-- Einwohnertabelle anzeigen
select
*
from ewz

'EINWOHNER AN DIE GEMEINDEN ANBINDEN'
-- Abfrage
select
h.GEOMETRY as GEOMETRY,
h.rs as rs,
h.gen as gen,
e.ewz as ewz
from hessen_etrs as h left outer join ewz as e on (e.rs = h.rs)  
-- hessen_etrs bekommt den Alias h und ewz den Alias e.
-- h.rs bedeutet die Spalte rs der tabelle h, was der Alias von hessen_etrs ist.
-- Mit left outer join wird die ewz-Tabelle angebunden
-- on (e.rs = h.rs)  verbindet beide Tabellen über die Schlüsselspalten h.rs und e.rs
-- In beiden Tabellen gibt es den Regionalschlüssel


'NEUER LAYER MIT EWZ ERZEUGEN'
create table hessen as --erzeugt eine neue Tabelle hessen aus der vorherigen Abfrage
select
h.GEOMETRY as GEOMETRY,
h.rs as rs,
h.gen as gen,
e.ewz as ewz
from hessen_etrs as h left outer join ewz as e on (e.rs = h.rs);

Select RecoverGeometryColumn("hessen",'GEOMETRY',25832,'MULTIPOLYGON');  --legt die Geometriespalte an
Select CreateSpatialIndex("hessen",'GEOMETRY');  --erzeugt einen räumlichen Index

'Geht auch über GUI-Funktionen:
Option: Create Spatial Table & load in QGIS'
--------

'INHALT VON GEMEINDEN UND LANDKREISEN ANZEIGEN'
select
*
from lkr
--dann
select
*
from hessen

'KREISID UND REGIONALSCHLÜSSEL VERGLEICHEN'
select
idkreis as id,                       -- idkreis wird als Spalte id ausgegeben
n_kreis as name                      -- nkreis wird als Spalte Name ausgeben
from lkr                             -- gewählt von der Tabelle Landkreise  
where n_kreis like 'Frankfurt%'      -- Nur Zeilen mit der Zeichenkette Frank in der Spalte n_kreis
   
union -- Beide Abfragen werden untereinandergeschrieben

select
rs as id,                            -- rs wird als Spalte id ausgegeben
gen as name                          -- gen wird als Spalte Name ausgebe
from hessen                          -- gewählt von der Tabelle hessen_etrs 
where gen  like 'Frankfurt%'         -- Nur Zeilen mit der Zeichenkette Frank in der Spalte gen

'ERGEBNIS:
idkreis aus lkr besteht aus dem 3. bis 5. Zeichen des Regionalschlüssel rs'

'KREISID AUS GMEINDE ANZEIGEN'
select
substr(rs,3,3) as krid -- aus der Spalte rs werden jeweils ab dem dritten Zeichen drei Zeichen in eine neue Spalte krid geschrieben
from hessen
(--substr gibt es auch als Funktion im Ausdruckseditor)

'GRUPPIEREN NACH LANDKREISBEZUG'
select
substr(rs,3,3) as krid
from hessen
group by substr(rs,3,3) -- Alle Zeilen mit dem gleichen krid werden zusammengefasst es gibt nur eine Zeile je landkreis

'WEITERE ZEILEN AUS DER GEMEINDETABELLE MITNEHMEN UND AGGREGIEREN UM DIE ANDEREN SPALTEN SINNVOLL ZUSAMMENZUFASSEN'
select
st_union(GEOMETRY) AS GEOMETRY,      --st_union (oder gunion) verschmilzt die Geometrien der gruppierten Zeilen also DISSOLVE!
astext(st_union(GEOMETRY)) AS WKT,    -- noch einmal als WKT-text ausgeben, um den Geometrietyp zu prüfen 
count(rs) as anzahl,                  -- die anzahl der zusammengefassten rs-Zeilen wird gezählt (Anzahl der Gemeinden im LKR)
group_concat(gen,'; ') as gem_liste,  -- Die Gemeindenamen aus der Spalte gen werden als Liste mit dem Trennzeichen Semikolon geschrieben
sum(ewz) as ewz_kreis,		      -- Die Einwohnerzahl der Gemeinden wird summiert
substr(rs,3,3) as krid
from hessen
group by substr(rs,3,3) 

'DEN GEOMETRIETYP GENERELL AUF MULTIPOLYGON SETZEN'

select
casttomultipolygon(st_union(GEOMETRY)) AS GEOMETRY, --- casttomultipolygon sorgt für durchgehend Multipolygon-Geometrien
count(rs) as anzahl,
group_concat(gen,'; ') as gem_liste,
sum(ewz) as ewz_kreis,
substr(rs,3,3) as krid
from hessen
group by substr(rs,3,3)

--LANDKREISNAMEN ANJOINEN

select
casttomultipolygon(st_union(h.GEOMETRY)) AS GEOMETRY, 
count(h.rs) as anzahl,
group_concat(h.gen,'; ') as gem_liste,
sum(h.ewz) as ewz_kreis,
l.N_KREIS as name,
substr(h.rs,3,3) as krid
from hessen as h inner join lkr as l on (l.IDKREIS = substr(h.rs,3,3)) -- die Landkreistabelle wird angehängt
group by substr(rs,3,3)

--Hiermit haben wir eine vollständige DISSOLVE-FUNKTION mit Agreggierung von Spalten.

create table landkreise as
select
casttomultipolygon(st_union(h.GEOMETRY)) AS GEOMETRY, 
count(h.rs) as anzahl,
group_concat(h.gen,'; ') as gem_liste,
sum(h.ewz) as ewz_kreis,
l.N_KREIS as name,
substr(h.rs,3,3) as krid
from hessen as h inner join lkr as l on (l.IDKREIS = substr(h.rs,3,3)) -- die Landkreistabelle wird angehängt
group by substr(rs,3,3)

Select RecoverGeometryColumn("landkreise",'GEOMETRY',25832,'MULTIPOLYGON');  --legt die Geometriespalte an
Select CreateSpatialIndex("landkreise",'GEOMETRY');  --erzeugt einen räumlichen Index


ogr2ogr -f SQLite -dsco SPATIALITE=yes -lco SRID=25832 -nln kreise -lco COMPRESS_GEOM=YES -skipfailures -gt 65536 -a_srs EPSG:25832 \
-sql"select casttomultipolygon(st_union(h.GEOMETRY)) AS GEOMETRY, \
count(h.rs) as anzahl, \
group_concat(h.gen,'; ') as gem_liste, \
sum(h.ewz) as ewz_kreis, \
l.N_KREIS as name, \
substr(h.rs,3,3) as krid \
from hessen as h inner join lkr as l on (l.IDKREIS = substr(h.rs,3,3)) \
group by substr(rs,3,3)"










/* 
-----------------------------------------
GKG-Kassel - Dr.-Ing. Claas Leiner
QGIS-Support und mehr

Geodatenservice, Kartenwerkstatt &
GIS-Schule Kassel

Wilhelmshöher Allee 304 E
34131 Kassel
Tel. 0561/56013445
claas.leiner@gkg-kassel.de
http://www.gkg-kassel.de
----------------------------------------
Unterstützen Sie QGIS
QGIS-DE e.V. | http://qgis.de
*/