select
st_difference(hessengemeinden.geometry,hessenwald.geometry) AS geometry,
hessengemeinden.GEN AS name
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
where GEN = 'Kassel'

--difference aus einzelner Gemeinde Attribute der Gemeinde bleiben erhalten
select
st_difference(hessengemeinden.geometry,Gunion(hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
where GEN = 'Kassel'

--difference für mehrere Gemeinden Attribute der Gemeinde bleiben erhalten
create table dreigemunion AS
select
st_difference(hessengemeinden.geometry,Gunion(hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry) 
where hessengemeinden.GEN = 'Kassel'
union
select
st_difference(hessengemeinden.geometry,Gunion(hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry) 
where hessengemeinden.GEN = 'Habichtswald'
union
select
st_difference(hessengemeinden.geometry,Gunion(hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry) 
where hessengemeinden.GEN = 'Schauenburg'


--difference fohne Attribute
create table dreidif2 AS
select
st_difference(Gunion(hessengemeinden.geometry),Gunion(hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
where hessengemeinden.GEN in ('Kassel','Habichtswald','Schauenburg')

---Difference ohne Attribute
select
st_difference(Gunion(hessengemeinden.geometry),Gunion(hessenwald.geometry)) AS geometry
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
where hessengemeinden.RS like '0663%' OR hessengemeinden.GEN = 'Kassel'


--Difference mit Attributen der gemeinde onne uniion
select
st_intersection(hessengemeinden.geometry,diff.geometry) AS geometry,
hessengemeinden.GEN AS name,
NULL AS veget
from hessengemeinden inner join 
    (select
    st_difference(Gunion(hessengemeinden.geometry),Gunion(hessenwald.geometry)) AS geometry,
    hessengemeinden.GEN AS name
    from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
    where hessengemeinden.GEN in ('Kassel','Habichtswald','Schauenburg'))  
AS diff on st_intersects(hessengemeinden.geometry,diff.geometry)
where hessengemeinden.GEN in ('Kassel','Habichtswald','Schauenburg')

--grosses gebiete
create table diffattribute AS
select
casttomultipolygon(st_intersection(hessengemeinden.geometry,diff.geometry)) AS geometry,
hessengemeinden.GEN AS name,
NULL AS veget
from hessengemeinden inner join 
    (select
    casttomultipolygon(st_difference(Gunion(hessengemeinden.geometry),Gunion(hessenwald.geometry))) AS geometry,
    hessengemeinden.GEN AS name
    from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
    where hessengemeinden.RS like '066%' OR hessengemeinden.RS like '065%')  
AS diff on st_intersects(hessengemeinden.geometry,diff.geometry)
where hessengemeinden.RS like '066%' OR hessengemeinden.RS like '065%'


-- gesamtunion
create table gesamtunion2 AS
select
casttomultipolygon(st_intersection(hessengemeinden.geometry,diff.geometry)) AS geometry,
hessengemeinden.GEN AS name,
NULL AS veget
from hessengemeinden inner join 
    (select
    casttomultipolygon(st_difference(Gunion(hessengemeinden.geometry),Gunion(hessenwald.geometry))) AS geometry,
    hessengemeinden.GEN AS name
    from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
    where hessengemeinden.RS like '066%' OR hessengemeinden.RS like '065%'  OR hessengemeinden.RS like '064%')  
AS diff on st_intersects(hessengemeinden.geometry,diff.geometry)
where hessengemeinden.RS like '066%' OR hessengemeinden.RS like '065%'  OR hessengemeinden.RS like '064%'
union
select
casttomultipolygon(st_intersection(hessengemeinden.geometry,hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name,
hessenwald.Veget AS veget
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
where hessengemeinden.RS like '066%' OR hessengemeinden.RS like '065%'  OR hessengemeinden.RS like '064%'

create tabele sysmdif as
select
casttomultipolygon(st_SymDifference(hessengemeinden.geometry,hessenwald.geometry)) AS geometry,
hessengemeinden.GEN AS name,
hessenwald.Veget AS veget
from hessengemeinden inner join hessenwald on st_intersects(hessengemeinden.geometry,hessenwald.geometry)
where hessengemeinden.RS like '066%' OR hessengemeinden.RS like '065%'  OR hessengemeinden.RS like '064%'


---Vereinigen ueber Linien
create table linienunion as
SELECT ST_Union(ST_DissolveSegments("geometry")) AS geometry
FROM(
  SELECT ST_Union(st_Boundary("geometry")) AS geometry
  FROM "hessengemeinden"
)

union

SELECT ST_Union(ST_DissolveSegments("geometry")) AS geometry
FROM(
  SELECT ST_Union(st_Boundary("geometry")) AS geometry
  FROM "hessenwald"
)
---
CREATE TABLE "splitlinie" AS
SELECT DissolveSegments("geometry") AS geometry
FROM (
  --- st_Union() splittet sich schneidender und uberlagender Linien an den Schnittpunkten in Liniensegmente 
  SELECT st_Union("geometry") AS geometry
  FROM "linienunion"
)
---
CREATE TABLE "poly2" AS 
SELECT 
CollectionExtract(BuildArea("geometry"),3) AS "geometry"
FROM "splitlinie"
ORDER BY ROWID
------------------------------------------


create table linienunion3 as
SELECT 
Gunion(ST_DissolveSegments(st_Boundary("geometry"))) AS geometry
FROM "hessengemeinden"
union
SELECT
Gunion(ST_DissolveSegments(st_Boundary("geometry"))) AS geometry
FROM "hessenwald"
;
Select RecoverGeometryColumn("linienunion3",'Geometry',25832,'Multiline');
Select CreateSpatialIndex("linienunion3",'Geometry');
create table pol4neu AS
Select
CollectionExtract(CastToMultipolygon(BuildArea(geometry)),3) AS geometry
from linienunion3
;
Select RecoverGeometryColumn("pol4neu",'Geometry',25832,'Multipolygon');
Select CreateSpatialIndex("pol4neu",'Geometry');


