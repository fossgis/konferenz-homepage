-- layer fuer Nutzungskartierung vorbereiten

--Layer mit Geometry anlegen
create table nutzung( 
"PKUID" INTEGER PRIMARY KEY AUTOINCREMENT, 
"geometry" Geometry, 
"nu_txt" text(50), 
"nu_code" numeric (2.1),
"FL" numeric (7.3));
Select RecoverGeometryColumn("nutzung",'Geometry',25832,'MULTIPOLYGON');
Select CreateSpatialIndex("nutzung",'Geometry');

---Tabelle fuer Werte für Werbeziehung anlegen
create table nuliste( 
"PKUID" INTEGER PRIMARY KEY AUTOINCREMENT, 
nu_txt text(50));

--Liste der Werte für Werbeziehung fuellen
insert into nuliste (nu_txt)
values ('Acker');
insert into nuliste (nu_txt)
values ('Grünland extensiv');
insert into nuliste (nu_txt)
values ('Grünland intensiv');
insert into nuliste (nu_txt)
values ('Feuchtgrünland');
insert into nuliste (nu_txt)
values ('Feuchtbrache');
insert into nuliste (nu_txt)
values ('Gewässer');
insert into nuliste (nu_txt)
values ('Laubwald');
insert into nuliste (nu_txt)
values ('Nadelwald');
insert into nuliste (nu_txt)
values ('Weg');
insert into nuliste (nu_txt)
values ('Straße');
insert into nuliste (nu_txt)
values ('Siedlung');


--automatische Flaechenberechnung bei geometriaenderung
CREATE TRIGGER flb_update
after update of geometry
on nutzung
begin
update nutzung set FL = round(((st_area(geometry)) / 1000000),3)
where rowid = new.rowid;
end;

--automatische Flaechenberechnung bei neuer geometrie
CREATE TRIGGER flb_insert
after insert on nutzung
begin
update nutzung set FL = round(((st_area(geometry)) / 1000000),3)
where rowid = new.rowid;
end;

--- Trigger um den Nutzungscode automatisch zu bestimmen
CREATE TRIGGER nucup
AFTER update of nu_txt
ON 'nutzung' for each row
begin
Update 'nutzung' SET nu_code = (
Case
when nu_txt = 'Acker' then 1
when nu_txt = 'Grünland extensiv' then 2.1
when nu_txt = 'Grünland intensiv' then 2.2
when nu_txt = 'Feuchtgrünland' then 2.3
when nu_txt = 'Feuchtbrache' then 5
when nu_txt = 'Gewässer' then 6
when nu_txt = 'Gehölz' then 7.1
when nu_txt = 'Laubwald' then 7.2
when nu_txt = 'Nadelwald' then 7.3
when nu_txt = 'Weg' then 8.1
when nu_txt = 'Straße' then 8.2
when nu_txt = 'Siedlung' then 8.3
End)
where rowid = new.rowid;
END;

CREATE TRIGGER nuinsert
AFTER INSERT
ON 'nutzung' for each row
begin
Update 'nutzung' SET nu_code = (
Case
when nu_txt = 'Acker' then 1
when nu_txt = 'Grünland extensiv' then 2.1
when nu_txt = 'Grünland intensiv' then 2.2
when nu_txt = 'Feuchtgrünland' then 2.3
when nu_txt = 'Feuchtbrache' then 5
when nu_txt = 'Gewässer' then 6
when nu_txt = 'Gehölz' then 7.1
when nu_txt = 'Laubwald' then 7.2
when nu_txt = 'Nadelwald' then 7.3
when nu_txt = 'Weg' then 8.1
when nu_txt = 'Straße' then 8.2
when nu_txt = 'Siedlung' then 8.3
End)
where rowid = new.rowid;
END;