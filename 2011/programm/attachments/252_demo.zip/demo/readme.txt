In dem Verzeichnis demo finden Sie weitere DemoRequests für GeoServer

Sie wurden für die Einbindung der Shapedatei countries_pl.shp konfiguriert.
countries_pl.shp
SRS 4326

Dabei lautet der Name des FeatureTypes laender.
Der namespace des FeatureTypes laender ist brd.


liegt der FeatureType brd:laender vor können Sie die Requests absetzen.

Kopieren Sie dazu die Dateien nach:
GEOSERVER_DATA_DIR/data/demo

Sie werden über die Demo-Requestseite auswählbar.
