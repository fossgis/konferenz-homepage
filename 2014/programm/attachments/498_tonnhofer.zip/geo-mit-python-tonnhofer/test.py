import json

from sqlalchemy import create_engine
from sqlalchemy import Column, String, Integer
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declarative_base

from geoalchemy2 import Geometry, WKTElement
from geoalchemy2.shape import to_shape, from_shape
from shapely.geometry import shape, Point
from pyproj import Proj, transform

import requests

Base = declarative_base()

class Trash(Base):
    __tablename__ = 'trashcans'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    art = Column(String)
    geom = Column(Geometry('POINT', srid=25832))


engine = create_engine('postgresql://localhost/olt')
Session = sessionmaker(bind=engine)
session = Session()

Base.metadata.create_all(engine)

# resp = requests.get('https://geo.sv.rostock.de/download/opendata/abfallbehaelter/abfallbehaelter.json')
# data = resp.json()
data = json.load(open('abfallbehaelter.json'))

# for f in data['features']:
#     geom = WKTElement(shape(f['geometry']).wkt, 4326)
#     t = Trash(
#         art=f['properties']['art'],
#         geom=func.st_transform(geom, 25832),
#     )
#     session.add(t)

# session.commit()

p4326 = Proj(init='epsg:4326')
p25832 = Proj(init='epsg:25832')

points = []
for f in data['features']:
    long, lat = f['geometry']['coordinates']
    points.append(
        transform(p4326, p25832, long, lat)
    )

point_geoms = []
for x, y in points:
    point_geoms.append(
        Point(x, y)
    )

loc = Point(701163, 6007829)
point_geoms.sort(key=lambda x: loc.distance(x))

for p in point_geoms[:3]:
    print p.wkt, loc.distance(p)


# loc = from_shape(Point(701163, 6007829), 25832)
# query = session.query(Trash).filter(
#     Trash.geom.intersects(
#         func.ST_Buffer(loc, 100)
#     )
# )

# for t in query:
#     print t.art, to_shape(t.geom)