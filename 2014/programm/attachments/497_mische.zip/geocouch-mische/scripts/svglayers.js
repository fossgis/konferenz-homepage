// SVG objects are loaded
$(window).bind('load', function() {
    var replaceObjectWithImg = function(object) {
        var serializer = new XMLSerializer();
        //var svg =  $('svg', this.contentDocument)[0];
        var svg = object[0].getSVGDocument().getElementsByTagName('svg')[0];
        console.log('mysvg0', svg);
        var svgString = serializer.serializeToString(svg);
        console.log('mysvg', svgString);
        var svgEscaped = escape(svgString);
        object.replaceWith('<img src="data:image/svg+xml,' + escape(svgString) +
                         '" />');
    };
    $('object').each(function() {
        var object = $(this);
        var svg =  $('svg', this.contentDocument);
        //var svgDocument = object[0].getSVGDocument();
        //var svg = $(svgDocument);
        if (svg) {
            // Set the viewBox of every included SVG so that it scales nicely
            // with the parent element
            svg.attr('viewBox', '0 0 ' + svg.attr('width') + ' ' +
                     svg.attr('height'));
            //.attr('preserveAspectRatio', 'xMinYMin meet')

            // Show the layers of the SVG as specified by data-show-layer
            var showLayer = object.attr('data-show-layer');
            if (showLayer) {
                var layers = svg.children('g').each(function() {
                    var layer = $(this);
                    var show = showLayer.split(/\s/);
                    console.log(layer.attr('inkscape:label'), show);
                    if($.inArray(layer.attr('inkscape:label'), show)!==-1) {
                        layer.css('display', 'inline');
                    }
                    else {
                        layer.css('display', 'none');
                    }
                });
            }
        }
        replaceObjectWithImg(object);
    });
});
